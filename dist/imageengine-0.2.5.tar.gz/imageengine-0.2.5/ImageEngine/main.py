from search_web import searchWeb
from search_duckduckgo import searchDDG
from search_google import searchGoogle
from search_bing import searchBing

if __name__ == '__main__':
    searchDDG("Ape", "ApeTown", 10)