from .search_duckduckgo import searchDDG
from .search_google import searchGoogle
from .search_bing import searchBing
from .search_web import searchWeb